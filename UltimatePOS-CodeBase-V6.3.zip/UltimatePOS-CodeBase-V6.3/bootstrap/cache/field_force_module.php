<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FieldForce\\Providers\\FieldForceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FieldForce\\Providers\\FieldForceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);