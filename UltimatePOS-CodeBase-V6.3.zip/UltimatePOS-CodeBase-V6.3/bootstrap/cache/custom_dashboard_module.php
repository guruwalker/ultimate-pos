<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomDashboard\\Providers\\CustomDashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomDashboard\\Providers\\CustomDashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);